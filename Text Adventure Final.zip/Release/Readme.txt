commands are {move,look,grab,show,talk} 
directions are {north,south,east,west,here} 
EVERYTHING MUST BE ENTERED IN LOWERCASE